Thanks for downloading Golden Ratio Demo !

You can check my other projects on Dribbble : https://dribbble.com/valentinfrancois

And you can buy the full font here : https://thehungryjpeg.com/product/30976-golden-ratio

Don't hesitate to show me what you do with this font !

Regards,

Valentin Fran�ois
contact@valentinfrancois.fr